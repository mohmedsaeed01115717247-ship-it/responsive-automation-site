import { SiteHeader } from '@/components/site/site-header'
import { Hero } from '@/components/site/hero'
import { LogoMarquee } from '@/components/site/logo-marquee'
import { ProcessSection } from '@/components/site/process-section'
import { ServicesOS } from '@/components/site/services-os'
import { PricingSection } from '@/components/site/pricing-section'
import { TeamNote } from '@/components/site/team-note'
import { CaseStudies } from '@/components/site/case-studies'
import { ComparisonSection } from '@/components/site/comparison-section'
import { Testimonials } from '@/components/site/testimonials'
import { StackSection } from '@/components/site/stack-section'
import { TeamSection } from '@/components/site/team-section'
import { FaqSection } from '@/components/site/faq-section'
import { BlogSection } from '@/components/site/blog-section'
import { ContactSection } from '@/components/site/contact-section'
import { SiteFooter } from '@/components/site/site-footer'
import { Reveal } from '@/components/site/reveal'

const sections = [
  ProcessSection,
  ServicesOS,
  PricingSection,
  TeamNote,
  CaseStudies,
  ComparisonSection,
  Testimonials,
  StackSection,
  TeamSection,
  FaqSection,
  BlogSection,
  ContactSection,
]

export default function Page() {
  return (
    <>
      <SiteHeader />
      <main>
        <Hero />
        <LogoMarquee />
        {sections.map((Section, i) => (
          <Reveal key={i}>
            <Section />
          </Reveal>
        ))}
      </main>
      <SiteFooter />
    </>
  )
}
