import { ArrowRight } from 'lucide-react'
import { posts } from '@/lib/site-data'
import { SectionLabel } from './logo'

export function BlogSection() {
  return (
    <section className="bg-background py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-14">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <SectionLabel>From the blog</SectionLabel>
            <h2 className="mt-5 text-4xl font-medium tracking-tight md:text-5xl">Recent writing.</h2>
          </div>
          <a href="#contact" className="inline-flex items-center gap-2 text-sm font-medium text-brand">
            All articles <ArrowRight className="size-4" aria-hidden="true" />
          </a>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {posts.map((p) => (
            <article key={p.title} className="group flex flex-col rounded-2xl border p-7 transition-colors hover:border-brand">
              <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
                {p.category} · {p.date}
              </p>
              <h3 className="mt-5 text-balance text-xl font-semibold leading-snug tracking-tight group-hover:text-brand">
                <a href="#contact">{p.title}</a>
              </h3>
              <p className="mt-3 flex-1 leading-relaxed text-muted-foreground">{p.excerpt}</p>
              <p className="mt-6 font-mono text-xs text-muted-foreground">{p.read}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
