import { Check, X } from 'lucide-react'
import { LogoMark, SectionLabel } from './logo'

const us = [
  'Vendor-agnostic. The right tool per problem, no lock-in.',
  "We tell you what isn't worth automating.",
  'Custom builds, never templates.',
  'We stay on the hook for the outcome.',
  'Fully managed: we monitor and tune what ships.',
  'Senior engineers, not account managers.',
]

const them = [
  'One tool, sold as strategy.',
  "Template solutions that don't fit.",
  'Build it, hand off, disappear.',
  "Padded invoices for work that doesn't move numbers.",
  'Lock-in to their own platform.',
  'A sales funnel, not an engineer.',
]

export function ComparisonSection() {
  return (
    <section className="bg-ink py-24 text-white md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-14">
        <SectionLabel className="text-white/60">The difference</SectionLabel>
        <h2 className="mt-5 text-balance text-4xl font-medium tracking-tight md:text-6xl">
          Not another <em className="text-brand-soft">AI agency.</em>
        </h2>

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          <div className="rounded-2xl bg-brand p-8">
            <p className="flex items-center gap-2.5 text-lg font-semibold">
              <LogoMark className="h-5" /> MJ Automation
            </p>
            <ul className="mt-6 space-y-4">
              {us.map((item) => (
                <li key={item} className="flex gap-3">
                  <Check className="mt-0.5 size-5 shrink-0" aria-hidden="true" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border border-white/15 p-8">
            <p className="text-lg font-semibold text-white/70">Most &ldquo;AI agencies&rdquo;</p>
            <ul className="mt-6 space-y-4 text-white/60">
              {them.map((item) => (
                <li key={item} className="flex gap-3">
                  <X className="mt-0.5 size-5 shrink-0 text-white/40" aria-hidden="true" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
