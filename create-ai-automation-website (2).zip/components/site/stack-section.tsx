import { stack } from '@/lib/site-data'
import { SectionLabel } from './logo'

export function StackSection() {
  return (
    <section className="bg-surface py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 text-center md:px-14">
        <SectionLabel className="justify-center">Stack</SectionLabel>
        <h2 className="mt-5 text-balance text-4xl font-medium tracking-tight md:text-6xl">
          Vendor-agnostic by design.
          <br />
          <em>Pick the right tool, every time.</em>
        </h2>
        <p className="mx-auto mt-6 max-w-xl text-pretty leading-relaxed text-muted-foreground">
          We integrate with the platforms your team is on today. No rip-and-replace. We mix what fits and keep up
          with the new stuff so you don&apos;t have to.
        </p>
        <ul className="mx-auto mt-12 flex max-w-5xl flex-wrap justify-center gap-2.5">
          {stack.map((s) => (
            <li
              key={s}
              className="rounded-full border bg-background px-4 py-2 text-sm font-medium transition-colors hover:border-brand hover:text-brand"
            >
              {s}
            </li>
          ))}
        </ul>
        <p className="mt-6 font-mono text-xs text-muted-foreground">and many more…</p>
      </div>
    </section>
  )
}
