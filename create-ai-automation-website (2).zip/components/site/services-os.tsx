'use client'

import { useState } from 'react'
import { ArrowRight, Check, Search } from 'lucide-react'
import { cn } from '@/lib/utils'
import { capabilities, subCapabilities } from '@/lib/site-data'
import { LogoMark, SectionLabel } from './logo'

export function ServicesOS() {
  const [activeId, setActiveId] = useState(capabilities[0].id)
  const active = capabilities.find((c) => c.id === activeId) ?? capabilities[0]

  return (
    <section id="services" className="bg-surface py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-14">
        <div className="mx-auto max-w-2xl text-center">
          <SectionLabel className="justify-center">What we build</SectionLabel>
          <h2 className="mt-5 text-balance text-4xl font-medium tracking-tight md:text-6xl">
            It looks like an operating system. <em className="text-brand">{"That's the point."}</em>
          </h2>
          <p className="mx-auto mt-6 max-w-lg text-pretty leading-relaxed text-muted-foreground">
            Most agencies hand you a pile of disconnected tools. We build the system that runs them, one capability
            at a time, all under one roof.
          </p>
        </div>

        <div className="mt-14 overflow-hidden rounded-2xl border bg-card shadow-[0_30px_80px_-30px_rgba(11,16,36,0.25)]">
          <div className="flex items-center gap-4 border-b px-4 py-3">
            <div className="flex gap-1.5" aria-hidden="true">
              <span className="size-2.5 rounded-full bg-[#ff5f57]" />
              <span className="size-2.5 rounded-full bg-[#febc2e]" />
              <span className="size-2.5 rounded-full bg-[#28c840]" />
            </div>
            <div className="flex items-center gap-2 text-sm font-medium">
              <LogoMark className="h-4" />
              MJ Automation
              <span className="hidden font-mono text-xs font-normal text-muted-foreground sm:inline">
                · AI Operating System
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3 border-b px-4 py-2.5">
            <div className="flex flex-1 items-center gap-2 rounded-lg bg-muted px-3 py-2 text-sm text-muted-foreground">
              <Search className="size-4" aria-hidden="true" />
              <span className="truncate">Find a capability, agent, or workflow…</span>
              <kbd className="ml-auto hidden rounded border bg-background px-1.5 font-mono text-[10px] sm:inline">
                Ctrl K
              </kbd>
            </div>
            <a
              href="#contact"
              className="shrink-0 rounded-lg bg-brand px-4 py-2 text-sm font-medium text-white hover:bg-brand/90"
            >
              Book a build
            </a>
          </div>

          <div className="grid lg:grid-cols-[260px_1fr]">
            <div className="border-b p-3 lg:border-b-0 lg:border-r">
              <p className="px-2 pb-2 pt-1 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                Capabilities
              </p>
              <div role="tablist" aria-label="Services" className="flex gap-1 overflow-x-auto lg:flex-col">
                {capabilities.map((c) => (
                  <button
                    key={c.id}
                    role="tab"
                    type="button"
                    id={`tab-${c.id}`}
                    aria-selected={c.id === activeId}
                    aria-controls="service-panel"
                    onClick={() => setActiveId(c.id)}
                    className={cn(
                      'flex shrink-0 items-center gap-2.5 rounded-lg px-3 py-2.5 text-left text-sm transition-colors',
                      c.id === activeId ? 'bg-brand/10 font-medium text-brand' : 'hover:bg-muted',
                    )}
                  >
                    <span
                      className={cn(
                        'size-1.5 rounded-full',
                        c.id === activeId ? 'bg-brand' : 'bg-muted-foreground/40',
                      )}
                      aria-hidden="true"
                    />
                    {c.title}
                  </button>
                ))}
              </div>
              <div className="mt-4 hidden border-t px-2 pt-4 lg:block">
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                  Agent capabilities · 11
                </p>
                <ul className="mt-3 space-y-1.5 text-xs text-muted-foreground">
                  {subCapabilities.slice(0, 6).map((s) => (
                    <li key={s} className="truncate">
                      {s}
                    </li>
                  ))}
                  <li className="text-brand">+5 more</li>
                </ul>
              </div>
            </div>

            <div
              id="service-panel"
              role="tabpanel"
              aria-labelledby={`tab-${active.id}`}
              className="grid gap-8 p-6 md:p-8 xl:grid-cols-[1fr_260px]"
            >
              <div key={active.id} className="animate-in fade-in slide-in-from-bottom-2 duration-500">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                    {active.kicker}
                  </span>
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-0.5 font-mono text-[11px] text-emerald-700">
                    <span className="size-1.5 animate-pulse rounded-full bg-emerald-500" aria-hidden="true" />
                    {active.status}
                  </span>
                </div>
                <h3 className="mt-3 text-3xl font-semibold tracking-tight">{active.title}</h3>
                <ul className="mt-4 flex flex-wrap gap-2">
                  {active.tags.map((t) => (
                    <li key={t} className="rounded-md border px-2.5 py-1 font-mono text-[11px] text-muted-foreground">
                      {t}
                    </li>
                  ))}
                </ul>
                <p className="mt-5 max-w-xl leading-relaxed text-muted-foreground">{active.description}</p>

                <div className="mt-6 rounded-xl bg-ink p-5 font-mono text-xs text-white/80">
                  <div className="flex items-center justify-between text-white/50">
                    <span>{active.id} / control plane</span>
                    <span className="text-emerald-400">● live</span>
                  </div>
                  <ul className="mt-4 space-y-3">
                    {active.bars.map((b, i) => (
                      <li key={b.label} className="grid grid-cols-[80px_1fr_36px] items-center gap-3">
                        <span className="truncate">{b.label}</span>
                        <span className="h-2 overflow-hidden rounded-full bg-white/10">
                          <span
                            className="block h-full animate-in slide-in-from-left-full rounded-full bg-gradient-to-r from-brand to-sky-400 duration-700 fill-mode-both"
                            style={{ width: `${b.value}%`, animationDelay: `${i * 90}ms` }}
                          />
                        </span>
                        <span className="text-right text-white/50">{b.value}%</span>
                      </li>
                    ))}
                  </ul>
                  <p className="mt-5 flex flex-wrap items-center gap-2 border-t border-white/10 pt-4 text-white/60">
                    {active.flow.map((f, i) => (
                      <span key={f} className="flex items-center gap-2">
                        {i > 0 && <span className="text-brand-soft">→</span>}
                        {f}
                      </span>
                    ))}
                  </p>
                </div>

                <div className="mt-4 rounded-xl border bg-muted/50 p-4 font-mono text-xs">
                  <p className="flex items-center justify-between text-muted-foreground">
                    activity <span className="text-emerald-600">live</span>
                  </p>
                  <ul className="mt-2 space-y-1">
                    {active.activity.map((a) => (
                      <li key={a}>
                        <span className="text-brand">{'>'}</span> {a}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <aside key={`${active.id}-aside`} className="animate-in fade-in duration-500">
                <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">What it does</p>
                <ul className="mt-3 space-y-2 text-sm">
                  {active.does.map((d) => (
                    <li key={d} className="flex items-center gap-2">
                      <Check className="size-4 shrink-0 text-brand" aria-hidden="true" />
                      {d}
                    </li>
                  ))}
                </ul>
                <p className="mt-7 font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                  {active.stackLabel}
                </p>
                <ul className="mt-3 flex flex-wrap gap-1.5">
                  {active.stack.map((s) => (
                    <li key={s} className="rounded-md bg-muted px-2 py-1 text-xs">
                      {s}
                    </li>
                  ))}
                </ul>
                <a
                  href="#contact"
                  className="mt-8 flex w-full items-center justify-center gap-2 rounded-lg bg-brand px-4 py-2.5 text-sm font-medium text-white hover:bg-brand/90"
                >
                  Start a build
                  <ArrowRight className="size-4" aria-hidden="true" />
                </a>
              </aside>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 border-t bg-muted/40 px-4 py-2 font-mono text-[11px] text-muted-foreground">
            <span className="text-emerald-600">● Connected</span>
            <span>6 capabilities · 1 operating system</span>
            <span className="hidden sm:inline">HQ → Worldwide</span>
          </div>
        </div>
      </div>
    </section>
  )
}
