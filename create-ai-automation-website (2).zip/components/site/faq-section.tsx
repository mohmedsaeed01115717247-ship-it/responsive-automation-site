import { ArrowRight, Plus } from 'lucide-react'
import { faqs } from '@/lib/site-data'
import { SectionLabel } from './logo'

export function FaqSection() {
  return (
    <section id="faq" className="bg-surface py-24 md:py-32">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 md:px-14 lg:grid-cols-[1fr_1.5fr]">
        <div>
          <SectionLabel>Frequently asked</SectionLabel>
          <h2 className="mt-5 text-4xl font-medium tracking-tight md:text-5xl">
            Questions, <em className="text-brand">straight answers.</em>
          </h2>
          <p className="mt-6 max-w-sm leading-relaxed text-muted-foreground">
            Anything else, book a free 30-minute call. No pitch deck; if there&apos;s no fit, we&apos;ll tell you.
          </p>
          <a
            href="#contact"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:bg-ink-soft"
          >
            Book a free consultation <ArrowRight className="size-4" aria-hidden="true" />
          </a>
        </div>
        <div className="divide-y border-y">
          {faqs.map((f) => (
            <details key={f.q} className="group py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-6 text-lg font-medium [&::-webkit-details-marker]:hidden">
                {f.q}
                <Plus
                  className="size-5 shrink-0 text-brand transition-transform group-open:rotate-45"
                  aria-hidden="true"
                />
              </summary>
              <p className="mt-4 pr-10 leading-relaxed text-muted-foreground">{f.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  )
}
