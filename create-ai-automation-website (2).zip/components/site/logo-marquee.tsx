import { clients } from '@/lib/site-data'

export function LogoMarquee() {
  const loop = [...clients, ...clients]
  return (
    <section aria-label="Trusted by" className="flex items-stretch overflow-hidden bg-brand text-white">
      <p className="relative z-10 hidden w-56 shrink-0 items-center bg-brand px-8 font-mono text-[11px] uppercase leading-relaxed tracking-[0.16em] text-white/85 shadow-[12px_0_24px_-8px] shadow-brand md:flex">
        Trusted by builders, operators & founders
      </p>
      <div className="flex-1 overflow-hidden py-6">
        <ul className="flex w-max animate-marquee gap-14 whitespace-nowrap pr-14">
          {loop.map((name, i) => (
            <li key={`${name}-${i}`} className="text-lg font-semibold tracking-tight" aria-hidden={i >= clients.length}>
              {name}
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
