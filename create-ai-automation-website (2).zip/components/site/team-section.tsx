import { ArrowUpRight } from 'lucide-react'
import { regions, team } from '@/lib/site-data'
import { SectionLabel } from './logo'

export function TeamSection() {
  return (
    <section id="team" className="bg-background py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-14">
        <SectionLabel>The people</SectionLabel>
        <h2 className="mt-5 text-4xl font-medium tracking-tight md:text-6xl">
          Senior engineers. <em className="text-brand">No middlemen.</em>
        </h2>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {team.map((m) => (
            <article key={m.name} className="flex flex-col rounded-2xl border p-7">
              <div
                className="flex size-14 items-center justify-center rounded-full bg-ink text-lg font-semibold text-white"
                aria-hidden="true"
              >
                {m.name
                  .split(' ')
                  .map((p) => p[0])
                  .join('')}
              </div>
              <h3 className="mt-6 text-xl font-semibold tracking-tight">{m.name}</h3>
              <p className="mt-1 font-mono text-xs uppercase tracking-[0.14em] text-brand">{m.role}</p>
              <p className="mt-4 flex-1 leading-relaxed text-muted-foreground">{m.bio}</p>
              <a href="#contact" className="mt-6 inline-flex items-center gap-1 text-sm font-medium">
                LinkedIn <ArrowUpRight className="size-4" aria-hidden="true" />
                <span className="sr-only">profile of {m.name}</span>
              </a>
            </article>
          ))}
        </div>

        <div className="mt-24 grid gap-10 border-t pt-14 md:grid-cols-3">
          {regions.map((r) => (
            <div key={r.title}>
              <h3 className="text-xl font-semibold tracking-tight">{r.title}</h3>
              <p className="mt-3 leading-relaxed text-muted-foreground">{r.body}</p>
              <ul className="mt-5 flex flex-wrap gap-2">
                {r.cities.map((c) => (
                  <li key={c} className="rounded-md bg-muted px-2.5 py-1 font-mono text-xs text-muted-foreground">
                    {c}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
