'use client'

import type { FormEvent } from 'react'
import { ArrowRight, Mail, MessageCircle, Phone } from 'lucide-react'
import { contactInfo } from '@/lib/site-data'
import { SectionLabel } from './logo'
import { SceneCanvas } from './scene-canvas'

export function ContactSection() {
  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const data = new FormData(e.currentTarget)
    const subject = `New inquiry from ${data.get('name')}`
    const body = `Name: ${data.get('name')}\nEmail: ${data.get('email')}\nCompany: ${data.get('company')}\n\n${data.get('message')}`
    window.location.href = `mailto:${contactInfo.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  }

  const field =
    'w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-white/35 transition-colors focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/40'

  const channels = [
    { icon: Phone, label: 'Call us', value: contactInfo.phone, href: contactInfo.phoneHref },
    { icon: MessageCircle, label: 'WhatsApp', value: contactInfo.phone, href: contactInfo.whatsappHref, external: true },
    { icon: Mail, label: 'Email', value: contactInfo.email, href: `mailto:${contactInfo.email}` },
  ]

  return (
    <section id="contact" className="relative overflow-hidden bg-ink py-24 text-white md:py-32">
      <div className="absolute -right-40 -top-40 size-[520px] rounded-full bg-brand/25 blur-[120px]" aria-hidden="true" />
      <div className="absolute -bottom-40 -left-40 size-[420px] rounded-full bg-glow/10 blur-[120px]" aria-hidden="true" />
      <div className="relative mx-auto grid max-w-7xl gap-14 px-5 md:px-14 lg:grid-cols-2">
        <div>
          <SectionLabel className="text-white/60">{"Let's talk"}</SectionLabel>
          <h2 className="mt-5 text-balance text-5xl font-semibold tracking-tight md:text-7xl">
            Tell us what&apos;s <span className="text-gradient">slowing you down.</span>
          </h2>
          <p className="mt-6 max-w-md text-lg leading-relaxed text-white/65">
            Book a free 30-minute consultation. We&apos;ll map where your time is going and tell you honestly what
            is worth automating.
          </p>

          <ul className="mt-10 grid gap-3">
            {channels.map((c) => (
              <li key={c.label}>
                <a
                  href={c.href}
                  target={c.external ? '_blank' : undefined}
                  rel={c.external ? 'noopener noreferrer' : undefined}
                  className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition-all hover:-translate-y-0.5 hover:border-brand/50 hover:bg-brand/10"
                >
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-brand to-glow text-white">
                    <c.icon className="size-5" aria-hidden="true" />
                  </span>
                  <span className="min-w-0">
                    <span className="block font-mono text-[11px] uppercase tracking-[0.16em] text-white/50">
                      {c.label}
                    </span>
                    <span className="block truncate text-base font-medium" dir="ltr">
                      {c.value}
                    </span>
                  </span>
                  <ArrowRight
                    className="ml-auto size-4 shrink-0 text-white/40 transition-transform group-hover:translate-x-1 group-hover:text-white"
                    aria-hidden="true"
                  />
                </a>
              </li>
            ))}
          </ul>

          <div className="pointer-events-none mt-6 hidden h-64 lg:block" aria-hidden="true">
            <SceneCanvas variant="knot" />
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="h-fit rounded-3xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur md:p-8"
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="name" className="mb-2 block text-sm text-white/70">
                Name
              </label>
              <input id="name" name="name" required autoComplete="name" className={field} placeholder="Your name" />
            </div>
            <div>
              <label htmlFor="email" className="mb-2 block text-sm text-white/70">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                autoComplete="email"
                className={field}
                placeholder="you@company.com"
              />
            </div>
          </div>
          <div className="mt-5">
            <label htmlFor="company" className="mb-2 block text-sm text-white/70">
              Company
            </label>
            <input id="company" name="company" autoComplete="organization" className={field} placeholder="Company name" />
          </div>
          <div className="mt-5">
            <label htmlFor="message" className="mb-2 block text-sm text-white/70">
              {"What's eating your team's time?"}
            </label>
            <textarea
              id="message"
              name="message"
              rows={5}
              required
              className={`${field} resize-none`}
              placeholder="Describe the workflow you want to automate…"
            />
          </div>
          <button
            type="submit"
            className="group mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-brand to-glow px-6 py-3.5 font-medium text-white transition-transform hover:-translate-y-0.5"
          >
            Send message{' '}
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
          </button>
        </form>
      </div>
    </section>
  )
}
