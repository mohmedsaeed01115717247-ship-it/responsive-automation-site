import { processSteps } from '@/lib/site-data'
import { SectionLabel } from './logo'

export function ProcessSection() {
  return (
    <section id="process" className="bg-background py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-14">
        <div className="mx-auto max-w-2xl text-center">
          <SectionLabel className="justify-center">How we work</SectionLabel>
          <h2 className="mt-5 text-balance text-4xl font-medium tracking-tight md:text-6xl">
            How does an <em className="text-brand">AI automation</em> engagement work?
          </h2>
          <p className="mx-auto mt-6 max-w-lg text-pretty leading-relaxed text-muted-foreground">
            Every engagement starts with the same four steps. We map your real workflows, rank what&apos;s worth
            building, ship it, then stay on the hook for the results.
          </p>
        </div>

        <ol className="relative mt-16 grid gap-10 md:grid-cols-2 lg:grid-cols-4 lg:gap-8">
          <span className="absolute left-0 right-0 top-6 hidden h-px bg-border lg:block" aria-hidden="true" />
          {processSteps.map((step, i) => (
            <li key={step.title} className="relative">
              <span
                className={`relative flex size-12 items-center justify-center rounded-xl font-mono text-sm ${
                  i === 0 ? 'bg-brand text-white' : 'border bg-background text-muted-foreground'
                }`}
              >
                {String(i + 1).padStart(2, '0')}
              </span>
              <h3 className="mt-6 text-xl font-semibold tracking-tight">{step.title}</h3>
              <p className="mt-3 leading-relaxed text-muted-foreground">{step.body}</p>
              <ul className="mt-5 space-y-1.5 font-mono text-xs text-muted-foreground">
                {step.items.map((item) => (
                  <li key={item} className="flex items-center gap-2">
                    <span className="size-1 rounded-full bg-brand" aria-hidden="true" />
                    {item}
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
