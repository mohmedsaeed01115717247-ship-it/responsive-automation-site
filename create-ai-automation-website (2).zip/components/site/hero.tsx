import { ArrowRight, Sparkles } from 'lucide-react'
import { SceneCanvas } from './scene-canvas'

const stats = [
  { value: '24/7', label: 'Automations that never sleep' },
  { value: '2–6 wks', label: 'From idea to live system' },
  { value: '100%', label: 'You own what we build' },
]

export function Hero() {
  return (
    <section id="top" className="relative isolate overflow-hidden bg-background">
      <div className="bg-grid absolute inset-0 -z-20 [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" aria-hidden="true" />
      <div className="absolute -left-40 top-20 -z-10 size-[520px] rounded-full bg-brand/25 blur-[120px]" aria-hidden="true" />
      <div className="absolute -right-20 bottom-0 -z-10 size-[420px] rounded-full bg-glow/15 blur-[120px]" aria-hidden="true" />

      <div className="mx-auto grid min-h-svh max-w-7xl items-center gap-6 px-5 pb-12 pt-28 md:px-14 lg:grid-cols-[1.1fr_1fr] lg:pt-24">
        <div className="relative z-10 animate-in fade-in slide-in-from-bottom-8 duration-1000">
          <p className="inline-flex items-center gap-2.5 rounded-full border border-brand/40 bg-brand/10 px-3.5 py-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-brand-soft md:text-xs">
            <Sparkles className="size-3.5" aria-hidden="true" />
            MJ Automation · AI agency
          </p>

          <h1 className="mt-6 text-balance text-5xl font-semibold leading-[1.02] tracking-tight sm:text-6xl lg:text-[5.2rem]">
            Automate the busywork. <span className="text-gradient">Scale what matters.</span>
          </h1>

          <p className="mt-7 max-w-lg text-pretty text-lg leading-relaxed text-muted-foreground">
            We build custom AI agents, voice assistants, and workflow automations that save your team hours every
            week. Built for outcomes, not buzzwords.
          </p>

          <div className="mt-9 flex flex-wrap gap-4">
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-glow px-6 py-3.5 text-[15px] font-medium text-white shadow-[0_10px_40px_-10px] shadow-brand transition-transform hover:-translate-y-0.5"
            >
              Book a free consultation{' '}
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
            </a>
            <a
              href="#services"
              className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-6 py-3.5 text-[15px] font-medium backdrop-blur transition-colors hover:bg-white/10"
            >
              Explore services
            </a>
          </div>

          <dl className="mt-14 grid max-w-xl grid-cols-3 gap-6 border-t border-white/10 pt-7">
            {stats.map((s) => (
              <div key={s.label}>
                <dt className="sr-only">{s.label}</dt>
                <dd className="text-xl font-semibold md:text-2xl">{s.value}</dd>
                <dd className="mt-1.5 font-mono text-[11px] leading-snug text-muted-foreground">{s.label}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div
          className="absolute inset-0 -z-10 opacity-40 lg:relative lg:inset-auto lg:z-0 lg:aspect-square lg:w-full lg:opacity-100"
          aria-hidden="true"
        >
          <SceneCanvas />
        </div>
      </div>
    </section>
  )
}
