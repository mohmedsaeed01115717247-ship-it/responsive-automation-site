import Image from 'next/image'
import { ArrowRight } from 'lucide-react'
import { caseStudies } from '@/lib/site-data'
import { SectionLabel } from './logo'

export function CaseStudies() {
  return (
    <section id="results" className="bg-surface py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-14">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <SectionLabel>Selected work</SectionLabel>
            <h2 className="mt-5 text-4xl font-medium tracking-tight md:text-6xl">
              Real builds. <em>Real outcomes.</em>
            </h2>
          </div>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 rounded-full border bg-background px-5 py-2.5 text-sm font-medium hover:bg-muted"
          >
            All case studies <ArrowRight className="size-4" aria-hidden="true" />
          </a>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-[1.4fr_1fr_1fr]">
          {caseStudies.map((c) => (
            <article key={c.title} className="group flex flex-col overflow-hidden rounded-2xl border bg-card">
              <div className="relative aspect-[16/11] overflow-hidden">
                <Image
                  src={c.image}
                  alt={c.alt}
                  fill
                  sizes="(min-width: 1024px) 33vw, 100vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <span className="absolute bottom-4 left-4 rounded-full bg-ink/70 px-3 py-1 font-mono text-[11px] text-white backdrop-blur">
                  {c.tag}
                </span>
              </div>
              <div className="flex flex-1 flex-col p-7">
                <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted-foreground">{c.category}</p>
                <h3 className="mt-4 text-balance text-2xl font-medium leading-tight tracking-tight">{c.title}</h3>
                <p className="mt-4 leading-relaxed text-muted-foreground">{c.body}</p>
                {c.stats && (
                  <dl className="mt-6 grid grid-cols-3 gap-4 border-y py-5">
                    {c.stats.map((s) => (
                      <div key={s.label}>
                        <dd className="text-2xl font-medium">{s.value}</dd>
                        <dt className="mt-1 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                          {s.label}
                        </dt>
                      </div>
                    ))}
                  </dl>
                )}
                <a
                  href="#contact"
                  className="mt-auto inline-flex items-center gap-2 pt-6 text-sm font-medium text-brand"
                >
                  Read the case study <ArrowRight className="size-4" aria-hidden="true" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
