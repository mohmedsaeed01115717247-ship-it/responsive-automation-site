import { SectionLabel } from './logo'

export function TeamNote() {
  return (
    <section className="bg-background py-24 md:py-32">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 md:px-14 lg:grid-cols-[1fr_1.4fr]">
        <div>
          <SectionLabel>Why we exist</SectionLabel>
          <h2 className="mt-5 text-4xl font-medium tracking-tight md:text-5xl">
            A note from <em className="text-brand">the team</em>
          </h2>
          <p className="mt-6 max-w-md leading-relaxed text-muted-foreground">
            MJ Automation is an AI automation agency. We design, build, and run custom AI agents, voice and chat
            automation, document and workflow systems, and predictive analytics for companies worldwide, then
            connect everything under one AI operating system your team can actually use.
          </p>
        </div>
        <figure className="border-l-2 border-brand pl-8">
          <blockquote className="space-y-6 text-pretty text-2xl font-medium leading-snug tracking-tight md:text-3xl">
            <p>
              We build real solutions for real companies. We don&apos;t sell software you don&apos;t need, and we
              don&apos;t pad invoices with work that doesn&apos;t move your numbers.
            </p>
            <p className="text-muted-foreground">
              Automation has limits. AI needs human judgment. Most &ldquo;AI agencies&rdquo; sell one tool and call it
              strategy. We pick the right combination, ship it, then stay on the hook for the outcome.
            </p>
          </blockquote>
          <figcaption className="mt-8 font-mono text-xs uppercase tracking-[0.16em] text-muted-foreground">
            The MJ Automation team
          </figcaption>
        </figure>
      </div>
    </section>
  )
}
