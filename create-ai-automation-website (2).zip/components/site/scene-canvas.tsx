'use client'

import dynamic from 'next/dynamic'

const Scene3D = dynamic(() => import('./scene-3d'), {
  ssr: false,
  loading: () => (
    <div className="flex size-full items-center justify-center">
      <div className="size-40 animate-pulse rounded-full bg-brand/20 blur-2xl" />
    </div>
  ),
})

export function SceneCanvas({ variant = 'orb' }: { variant?: 'orb' | 'knot' }) {
  return <Scene3D variant={variant} />
}
