import { ArrowRight, Check, Clock, Layers, Repeat } from 'lucide-react'
import { SectionLabel } from './logo'

const hire = [
  ['Cost', 'Salary + benefits, every year'],
  ['Ramp to productive', '4 to 8 weeks'],
  ['Capacity', '40 hrs / wk'],
  ['Scales with growth', 'Hire again'],
]

const automate = [
  ['Cost', 'Scoped to your workflow'],
  ['Live in', '2 to 6 weeks'],
  ['Capacity', '24 / 7 / 365'],
  ['Ownership', 'You own the build'],
]

const models = [
  {
    icon: Layers,
    title: 'Project-based',
    body: 'A fixed scope for a specific automation, agent, or app. Clear deliverables and timeline.',
  },
  {
    icon: Clock,
    title: 'Hourly consulting',
    body: 'Flexible expert time for strategy, audits, and smaller improvements to your systems.',
  },
  {
    icon: Repeat,
    title: 'Monthly retainer',
    body: 'Ongoing support, monitoring, and new builds as your business grows.',
    accent: true,
  },
]

export function PricingSection() {
  return (
    <section id="pricing" className="relative overflow-hidden bg-ink py-24 text-white md:py-32">
      <div className="absolute left-1/2 top-0 size-[600px] -translate-x-1/2 rounded-full bg-brand/10 blur-[140px]" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-5 md:px-14">
        <SectionLabel className="text-white/60">How we work together</SectionLabel>
        <h2 className="mt-6 text-balance text-4xl font-semibold tracking-tight md:text-6xl">
          Automate repeatable work.
          <br />
          <span className="text-gradient">Pick the model that fits.</span>
        </h2>

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          <div className="rounded-3xl border border-white/10 bg-white/[0.02] p-8">
            <p className="font-mono text-xs uppercase tracking-[0.16em] text-white/50">/ Option A, hire for it</p>
            <h3 className="mt-3 text-2xl font-medium">Hire another person.</h3>
            <dl className="mt-6">
              {hire.map(([k, v]) => (
                <div key={k} className="flex items-center justify-between gap-4 border-b border-white/10 py-3.5">
                  <dt className="text-white/60">{k}</dt>
                  <dd className="text-right font-mono text-sm">{v}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="relative rounded-3xl bg-gradient-to-br from-brand/60 via-brand/20 to-glow/40 p-px">
            <div className="h-full rounded-[calc(1.5rem-1px)] bg-[#0f0d26] p-8">
              <p className="font-mono text-xs uppercase tracking-[0.16em] text-brand-soft">/ Option B, automate it</p>
              <h3 className="mt-3 text-2xl font-medium">
                Build it once. <span className="text-gradient">Own it.</span>
              </h3>
              <dl className="mt-6">
                {automate.map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between gap-4 border-b border-white/10 py-3.5">
                    <dt className="text-white/60">{k}</dt>
                    <dd className="inline-flex items-center gap-2 text-right font-mono text-sm">
                      <Check className="size-3.5 text-glow" aria-hidden="true" />
                      {v}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>

        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {models.map((m) => (
            <div
              key={m.title}
              className="group rounded-3xl border border-white/10 bg-white/[0.02] p-8 transition-all duration-500 hover:-translate-y-1.5 hover:border-brand/50 hover:bg-brand/5"
            >
              <span className="flex size-12 items-center justify-center rounded-2xl bg-brand/15 text-brand-soft transition-transform duration-500 group-hover:rotate-12">
                <m.icon className="size-5" aria-hidden="true" />
              </span>
              <h3 className={`mt-6 text-2xl font-medium ${m.accent ? 'text-brand-soft' : ''}`}>{m.title}</h3>
              <p className="mt-3 leading-relaxed text-white/65">{m.body}</p>
              <p className="mt-6 font-mono text-xs uppercase tracking-[0.16em] text-white/45">Custom quote</p>
            </div>
          ))}
        </div>

        <a href="#contact" className="mt-10 inline-flex items-center gap-2 text-sm text-brand-soft hover:underline">
          Get a custom quote <ArrowRight className="size-4" aria-hidden="true" />
        </a>
      </div>
    </section>
  )
}
