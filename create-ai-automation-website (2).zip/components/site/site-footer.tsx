import { capabilities, navLinks } from '@/lib/site-data'
import { Logo } from './logo'

export function SiteFooter() {
  return (
    <footer className="border-t border-white/10 bg-ink text-white">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-[1.5fr_1fr_1fr] md:px-14">
        <div>
          <Logo />
          <p className="mt-5 max-w-xs leading-relaxed text-white/60">
            AI automation that gives your team its time back. Custom agents, workflows, and operating systems.
          </p>
        </div>
        <nav aria-label="Footer services">
          <p className="font-mono text-xs uppercase tracking-[0.16em] text-white/50">Services</p>
          <ul className="mt-4 space-y-2.5 text-sm text-white/75">
            {capabilities.map((c) => (
              <li key={c.id}>
                <a href="#services" className="hover:text-white">
                  {c.title}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <nav aria-label="Footer company">
          <p className="font-mono text-xs uppercase tracking-[0.16em] text-white/50">Company</p>
          <ul className="mt-4 space-y-2.5 text-sm text-white/75">
            {navLinks.slice(1).map((l) => (
              <li key={l.href}>
                <a href={l.href} className="hover:text-white">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-wrap justify-between gap-3 px-5 py-6 font-mono text-xs text-white/50 md:px-14">
          <p>© {new Date().getFullYear()} MJ Automation. All rights reserved.</p>
          <p>Built for outcomes, not buzzwords.</p>
        </div>
      </div>
    </footer>
  )
}
