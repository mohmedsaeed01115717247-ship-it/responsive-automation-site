import { cn } from '@/lib/utils'

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 40 26"
      fill="none"
      aria-hidden="true"
      className={cn('h-6 w-auto', className)}
    >
      <path
        d="M3.5 22 V5 L11.5 14.5 L19.5 5 V22"
        stroke="currentColor"
        strokeWidth="3.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M32 5 V16.5 Q32 22 26.5 22"
        stroke="currentColor"
        strokeWidth="3.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="37" cy="5" r="2.2" fill="#22d3ee" />
    </svg>
  )
}

export function Logo({ className }: { className?: string }) {
  return (
    <a href="#top" className={cn('flex items-center gap-2.5 font-semibold tracking-tight', className)}>
      <LogoMark className="text-brand-soft" />
      <span className="text-lg">MJ Automation</span>
    </a>
  )
}

export function SectionLabel({
  children,
  className,
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <p
      className={cn(
        'flex items-center gap-2.5 font-mono text-xs uppercase tracking-[0.18em] text-muted-foreground',
        className,
      )}
    >
      <span className="size-1.5 rounded-full bg-brand" aria-hidden="true" />
      {children}
    </p>
  )
}
