'use client'

import { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, MeshDistortMaterial, Sparkles } from '@react-three/drei'
import { MathUtils, type Group, type Mesh } from 'three'

function Satellites() {
  const orbit = useRef<Group>(null)
  useFrame((_, delta) => {
    if (orbit.current) orbit.current.rotation.y -= delta * 0.25
  })
  return (
    <group ref={orbit}>
      <Float speed={3} floatIntensity={1.4} rotationIntensity={2}>
        <mesh position={[2.6, 0.9, 0]}>
          <octahedronGeometry args={[0.22]} />
          <meshStandardMaterial color="#22d3ee" emissive="#22d3ee" emissiveIntensity={0.8} metalness={0.3} roughness={0.2} />
        </mesh>
      </Float>
      <Float speed={2.4} floatIntensity={1.2} rotationIntensity={2}>
        <mesh position={[-2.4, -1.1, 0.6]}>
          <torusKnotGeometry args={[0.16, 0.05, 96, 16]} />
          <meshStandardMaterial color="#c4b8ff" emissive="#7c6cff" emissiveIntensity={0.6} metalness={0.5} roughness={0.2} />
        </mesh>
      </Float>
      <Float speed={2} floatIntensity={1} rotationIntensity={2}>
        <mesh position={[0.4, -2.2, -1]}>
          <boxGeometry args={[0.28, 0.28, 0.28]} />
          <meshStandardMaterial color="#7c6cff" emissive="#7c6cff" emissiveIntensity={0.5} metalness={0.4} roughness={0.25} />
        </mesh>
      </Float>
      <Float speed={2.8} floatIntensity={1.3} rotationIntensity={2}>
        <mesh position={[-1, 2.1, -0.6]}>
          <icosahedronGeometry args={[0.18, 0]} />
          <meshStandardMaterial color="#ffffff" emissive="#22d3ee" emissiveIntensity={0.4} metalness={0.4} roughness={0.2} />
        </mesh>
      </Float>
    </group>
  )
}

function Core({ variant }: { variant: 'orb' | 'knot' }) {
  const group = useRef<Group>(null)
  const ringA = useRef<Mesh>(null)
  const ringB = useRef<Mesh>(null)

  useFrame((state, delta) => {
    const g = group.current
    if (g) {
      g.rotation.y += delta * 0.12
      g.rotation.x = MathUtils.lerp(g.rotation.x, state.pointer.y * 0.35, 0.05)
      g.position.x = MathUtils.lerp(g.position.x, state.pointer.x * 0.25, 0.05)
    }
    if (ringA.current) ringA.current.rotation.z += delta * 0.35
    if (ringB.current) ringB.current.rotation.x += delta * 0.25
  })

  return (
    <group ref={group}>
      <Float speed={1.8} rotationIntensity={0.5} floatIntensity={0.7}>
        {variant === 'orb' ? (
          <mesh>
            <icosahedronGeometry args={[1.25, 24]} />
            <MeshDistortMaterial
              color="#6a5cff"
              emissive="#24156e"
              emissiveIntensity={0.7}
              roughness={0.12}
              metalness={0.65}
              distort={0.4}
              speed={2}
            />
          </mesh>
        ) : (
          <mesh>
            <torusKnotGeometry args={[0.95, 0.32, 220, 32]} />
            <MeshDistortMaterial
              color="#6a5cff"
              emissive="#24156e"
              emissiveIntensity={0.7}
              roughness={0.15}
              metalness={0.6}
              distort={0.2}
              speed={1.5}
            />
          </mesh>
        )}
        <mesh>
          <icosahedronGeometry args={[1.85, 1]} />
          <meshBasicMaterial color="#22d3ee" wireframe transparent opacity={0.18} />
        </mesh>
      </Float>
      <mesh ref={ringA} rotation={[Math.PI / 2.3, 0, 0]}>
        <torusGeometry args={[2.35, 0.012, 16, 200]} />
        <meshBasicMaterial color="#c4b8ff" transparent opacity={0.65} />
      </mesh>
      <mesh ref={ringB} rotation={[0, Math.PI / 3, Math.PI / 4]}>
        <torusGeometry args={[2.8, 0.008, 16, 200]} />
        <meshBasicMaterial color="#22d3ee" transparent opacity={0.45} />
      </mesh>
      <Satellites />
    </group>
  )
}

export default function Scene3D({ variant = 'orb' }: { variant?: 'orb' | 'knot' }) {
  return (
    <Canvas camera={{ position: [0, 0, 7], fov: 45 }} dpr={[1, 1.75]} gl={{ antialias: true, alpha: true }}>
      <ambientLight intensity={0.35} />
      <pointLight position={[4, 3, 4]} intensity={60} color="#a78bfa" />
      <pointLight position={[-4, -2, 3]} intensity={45} color="#22d3ee" />
      <directionalLight position={[0, 5, 5]} intensity={0.8} />
      <Core variant={variant} />
      <Sparkles count={90} scale={[9, 6, 4]} size={2.2} speed={0.4} color="#c4b8ff" />
    </Canvas>
  )
}
