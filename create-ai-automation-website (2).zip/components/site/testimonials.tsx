'use client'

import { useEffect, useState } from 'react'
import { Star } from 'lucide-react'
import { cn } from '@/lib/utils'
import { testimonials } from '@/lib/site-data'
import { SectionLabel } from './logo'

export function Testimonials() {
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)

  useEffect(() => {
    if (paused) return
    const id = setInterval(() => setIndex((i) => (i + 1) % testimonials.length), 7000)
    return () => clearInterval(id)
  }, [paused])

  const t = testimonials[index]

  return (
    <section
      className="bg-background py-24 md:py-32"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="mx-auto max-w-7xl px-5 md:px-14">
        <SectionLabel>What clients say</SectionLabel>
        <figure key={index} className="mt-8 max-w-4xl animate-in fade-in duration-700" aria-live="polite">
          <blockquote className="text-pretty text-2xl font-medium leading-snug tracking-tight md:text-4xl md:leading-tight">
            &ldquo;{t.quote}
            <span className="text-brand">&rdquo;</span>
          </blockquote>
          <figcaption className="mt-8 flex flex-wrap items-center gap-4">
            <span className="inline-flex items-center gap-2 rounded-full border border-amber-200 bg-amber-50 px-3 py-1.5">
              <span className="flex gap-0.5" aria-label="5 out of 5 stars">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="size-3.5 fill-amber-500 text-amber-500" aria-hidden="true" />
                ))}
              </span>
              <span className="font-mono text-xs text-amber-800">
                5.0 <span className="text-amber-600/60">/ 5</span>
              </span>
            </span>
            <span className="font-medium">{t.name}</span>
            <span className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground">{t.meta}</span>
          </figcaption>
        </figure>

        <div className="mt-10 flex gap-2" role="tablist" aria-label="Choose testimonial">
          {testimonials.map((item, i) => (
            <button
              key={item.name}
              type="button"
              role="tab"
              aria-selected={i === index}
              aria-label={`Testimonial from ${item.name}`}
              onClick={() => setIndex(i)}
              className={cn(
                'h-2 rounded-full transition-all',
                i === index ? 'w-6 bg-brand' : 'w-2 bg-border hover:bg-muted-foreground/40',
              )}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
