export const contactInfo = {
  phone: '01115717247',
  phoneHref: 'tel:+201115717247',
  whatsappHref: 'https://wa.me/201115717247',
  email: 'mjautomation.agency@gmail.com',
}

export const navLinks = [
  { label: 'Home', href: '#top' },
  { label: 'Process', href: '#process' },
  { label: 'Services', href: '#services' },
  { label: 'Plans', href: '#pricing' },
  { label: 'Results', href: '#results' },
  { label: 'Team', href: '#team' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Contact', href: '#contact' },
]

export const clients = [
  'NorthPeak Energy',
  'Brightline Logistics',
  'Vantage Realty',
  'Clearwater Health',
  'Ironbridge Construction',
  'Nimbus Labs',
  'Atlas Mechanical',
  'Solace Clinics',
  'Meridian Finance',
  'Harbor & Co',
  'Evergreen Recycling',
  'Pulse Commerce',
  'Summit Legal',
  'Orbit Studios',
]

export const processSteps = [
  {
    title: 'Discover & map',
    body: 'We sit with your team, draw your real workflows, and find where money is leaking out.',
    items: ['Workflow audit', 'Systems map', 'ROI shortlist'],
  },
  {
    title: 'Opportunity analysis',
    body: "We rank what's worth automating. We tell you what isn't. We pick the highest-ROI fights first.",
    items: ['Impact / effort matrix', 'Build vs. buy call', 'Scoped proposal'],
  },
  {
    title: 'Build & integrate',
    body: 'Vendor-agnostic builds in n8n, Python, Retell, GPT, Gemini. Chosen for the job, not the brochure.',
    items: ['Two-week sprints', 'Live test data', 'Hand-off docs'],
  },
  {
    title: 'Optimise & scale',
    body: '24/7 monitoring, monthly tuning, and quarterly reviews. We stay on the hook for outcomes.',
    items: ['SLA dashboard', 'Continuous tuning', 'Quarterly ROI'],
  },
]

export type Capability = {
  id: string
  kicker: string
  title: string
  status: string
  tags: string[]
  description: string
  flow: string[]
  activity: string[]
  does: string[]
  stackLabel: string
  stack: string[]
  bars: { label: string; value: number }[]
}

export const capabilities: Capability[] = [
  {
    id: 'agents',
    kicker: 'Hub · 11 capabilities',
    title: 'AI Agent Development',
    status: 'running',
    tags: ['11 capabilities', 'Live in 2 to 6 weeks', 'Custom quote, you own it'],
    description:
      'Custom AI agents and automations, from voice and chat to documents, workflows, and predictive systems, built for your business.',
    flow: ['Design', 'Build', 'Deploy', 'Iterate'],
    activity: ['trigger: event received', 'planner: task routed to agent', 'deploy: shipped to production [ok]'],
    does: ['Voice and chat agents', 'Document and workflow automation', 'Predictive systems', 'One capability or many'],
    stackLabel: 'Runs on',
    stack: ['n8n', 'ChatGPT', 'Gemini', 'Retell AI', 'Python'],
    bars: [
      { label: 'trigger', value: 92 },
      { label: 'voice', value: 74 },
      { label: 'planner', value: 66 },
      { label: 'deploy', value: 84 },
    ],
  },
  {
    id: 'os',
    kicker: 'Platform · the flagship',
    title: 'AI Operating Systems',
    status: '6 agents live',
    tags: ['Vendor-agnostic', 'Connects any tool', 'You own it'],
    description:
      'One central operating system to deploy, orchestrate, and govern every AI agent and automation you run.',
    flow: ['Connect', 'Orchestrate', 'Govern', 'Scale'],
    activity: ['os: 6 agents online', 'voice -> crm: lead synced', 'govern: policy applied [ok]'],
    does: ['Deploy agents', 'Orchestrate cross-tool', 'Govern and permission', 'Monitor live'],
    stackLabel: 'Connects',
    stack: ['Any API', 'n8n', 'Webhooks', 'Your CRM'],
    bars: [
      { label: 'voice', value: 88 },
      { label: 'chat', value: 80 },
      { label: 'docs', value: 70 },
      { label: 'workflow', value: 94 },
      { label: 'crm', value: 76 },
    ],
  },
  {
    id: 'marketing',
    kicker: 'Growth',
    title: 'AI Marketing',
    status: 'converting',
    tags: ['Multi-channel', 'One growth engine', 'Owned, not rented'],
    description:
      'Lead generation, CRM, campaigns, content, and ecommerce personalization, wired into one growth engine.',
    flow: ['Capture', 'Nurture', 'Convert', 'Retain'],
    activity: ['capture: form submit -> lead', 'score: 82, sales-ready', 'crm: opportunity created [ok]'],
    does: ['Lead generation', 'CRM automation', 'Campaigns and content', 'Ecommerce personalization'],
    stackLabel: 'Runs on',
    stack: ['CRM', 'n8n', 'ChatGPT', 'Ads APIs'],
    bars: [
      { label: 'visitors', value: 96 },
      { label: 'leads', value: 64 },
      { label: 'customers', value: 38 },
      { label: 'pipeline', value: 72 },
    ],
  },
  {
    id: 'consulting',
    kicker: 'Advisory',
    title: 'AI Consulting',
    status: 'mapping',
    tags: ['Outcome-first', 'Roadmap in weeks', 'No vendor bias'],
    description:
      'Strategy, readiness, and roadmaps. We help you decide where AI and automation actually pay off, then plan the build.',
    flow: ['Assess', 'Map', 'Roadmap', 'Build'],
    activity: ['assess: 14 processes scanned', 'rank: top 3 by ROI', 'roadmap: 4 phases drafted [ok]'],
    does: ['AI readiness assessment', 'Opportunity mapping', 'Build roadmap', 'ROI modelling'],
    stackLabel: 'Delivered as',
    stack: ['Workshops', 'Audit', 'Roadmap', 'ROI model'],
    bars: [
      { label: 'assess', value: 100 },
      { label: 'map', value: 70 },
      { label: 'build', value: 30 },
      { label: 'scale', value: 12 },
    ],
  },
  {
    id: 'training',
    kicker: 'Enablement',
    title: 'AI Training & Enablement',
    status: 'in session',
    tags: ['Workshops', 'Custom playbooks', 'Adoption that sticks'],
    description:
      'Hands-on workshops, custom playbooks, and adoption programs that get your team fluent and actually using the AI you run.',
    flow: ['Assess', 'Train', 'Embed', 'Support'],
    activity: ['cohort: 12 enrolled', 'module: prompting complete', 'team: fluency climbing [ok]'],
    does: ['Hands-on workshops', 'Custom playbooks', 'Role-based programs', 'Office hours and support'],
    stackLabel: 'Delivered as',
    stack: ['Workshops', 'Playbooks', 'Labs', 'Office hours'],
    bars: [
      { label: 'prompting', value: 82 },
      { label: 'agents', value: 58 },
      { label: 'automations', value: 40 },
      { label: 'safe use', value: 20 },
    ],
  },
  {
    id: 'web',
    kicker: 'Build',
    title: 'Web & Mobile Development',
    status: 'shipping',
    tags: ['React · Next.js · React Native', 'MVP to enterprise', 'AI built in'],
    description: 'Custom React, Next.js, and React Native apps, from MVP to enterprise, with AI built in.',
    flow: ['Design', 'Build', 'Test', 'Ship'],
    activity: ['build: compiling next.js', 'test: 128 passed', 'live: deployed [ok]'],
    does: ['Web apps', 'Mobile apps', 'AI built in', 'MVP to enterprise'],
    stackLabel: 'Runs on',
    stack: ['React', 'Next.js', 'React Native', 'TypeScript'],
    bars: [
      { label: 'design', value: 100 },
      { label: 'build', value: 86 },
      { label: 'test', value: 72 },
      { label: 'ship', value: 60 },
    ],
  },
]

export const subCapabilities = [
  'Agentic AI & Multi-Agent Systems',
  'AI Copilots',
  'Computer-Use & RPA Automation',
  'Finance & Accounting Automation',
  'AI Voice Agents',
  'Chatbots & Conversational AI',
  'Document & Content Processing',
  'Workflow & Process Automation',
  'Predictive Analytics & BI',
  'AI HR & Talent',
  'Predictive Maintenance & IoT',
]

export const caseStudies = [
  {
    image: '/images/case-fashion.png',
    alt: 'Editorial fashion detail: cream silk outfit with a wristwatch',
    tag: '// product · fashion AI',
    category: 'Consumer · AI',
    title: 'Launching an AI fashion assistant to 2,000+ users',
    body: 'MVP design and build, ongoing AI capability work. 800+ paid subscribers in the first phase.',
    stats: [
      { value: '2,000+', label: 'Active users' },
      { value: '800+', label: 'Paid subscribers' },
      { value: '14 wks', label: 'MVP to launch' },
    ],
  },
  {
    image: '/images/case-hvac.png',
    alt: 'Rooftop HVAC units on a commercial building',
    tag: '// platform · HVAC AI',
    category: 'Commercial RE · Energy',
    title: 'A 25% cut in HVAC energy use for a commercial portfolio',
    body: 'AI-driven HVAC coordination optimising energy consumption while maintaining comfort across large commercial buildings.',
  },
  {
    image: '/images/case-seo.png',
    alt: 'Laptop showing a web analytics dashboard with rising traffic',
    tag: '// platform · web + SEO',
    category: 'Marketing · Web Dev',
    title: '15+ sites and a 40% lift in organic traffic',
    body: 'End-to-end website development with AI-powered SEO automation. Target-keyword rankings improved 55%.',
  },
]

export const testimonials = [
  {
    quote:
      'Working with the team has been a great experience. They take the time to walk you through new developments in the AI world and how they can be implemented to better serve your company. Thorough, professional, and a level of expertise in every process.',
    name: 'Hudson D.',
    meta: 'Google review · Jan 2026',
  },
  {
    quote:
      "MJ Automation is my AI strategy partner. I wasn't even sure what was possible with AI, but over the discovery call they uncovered areas where I could implement it. I've already seen a large ROI on my investment.",
    name: 'Dianne C.',
    meta: 'Google review · Jul 2025',
  },
  {
    quote:
      'Knowledgeable, forward thinking, and true experts in the ever evolving world of AI and automation. For any business looking to streamline and become more efficient, you will not be disappointed.',
    name: 'Robert S.',
    meta: 'Google review · Jun 2026',
  },
  {
    quote: 'They sent me a ready-to-use prompt that was incredibly helpful from day one!',
    name: 'Ruhina S.',
    meta: 'Google review · May 2026',
  },
  {
    quote: 'Helpful, patient support getting our voice agent live with Retell AI.',
    name: 'Ennio Z.',
    meta: 'Google review · Jun 2026',
  },
  {
    quote: 'Reliable team that went above and beyond!',
    name: 'Kevin H.',
    meta: 'Google review · Jun 2026',
  },
]

export const stack = [
  'n8n',
  'Make',
  'Zapier',
  'OpenAI',
  'Anthropic',
  'Google Gemini',
  'ElevenLabs',
  'Python',
  'TypeScript',
  'Next.js',
  'Supabase',
  'AWS',
  'Azure',
  'Vercel',
  'Salesforce',
  'HubSpot',
  'Slack',
  'Airtable',
  'Notion',
  'Monday.com',
  'Stripe',
  'QuickBooks',
  'Twilio',
  'Microsoft 365',
  'Google Workspace',
  'GitHub',
  'Pinecone',
]

export const team = [
  {
    name: 'Omar Hassan',
    role: 'Cofounder · Technology',
    bio: 'Software engineer with ten-plus years in full-stack and IoT and an MS in Data Analytics. He architects the systems our automations run on.',
  },
  {
    name: 'Youssef Adel',
    role: 'Cofounder · Operations',
    bio: 'Connects AI capability to practical business. He leads strategy and delivery so every build ships with measurable ROI.',
  },
  {
    name: 'Mariam Khaled',
    role: 'AI Engineer',
    bio: 'Builds and ships the AI automation workflows behind client projects.',
  },
]

export const regions = [
  {
    title: 'Middle East & North Africa',
    body: 'From our regional HQ we serve every major market, from Cairo and Dubai to Riyadh, Doha, and beyond.',
    cities: ['Cairo', 'Dubai', 'Riyadh', 'Doha', 'Jeddah', 'Abu Dhabi', 'Kuwait', 'Amman'],
  },
  {
    title: 'North America',
    body: 'Remote-first delivery for U.S. and Canadian teams, from New York and Toronto to the Bay Area.',
    cities: ['New York', 'Toronto', 'Chicago', 'Los Angeles', 'Austin', 'Miami', 'Seattle', 'Boston'],
  },
  {
    title: 'Global reach',
    body: 'Time-zone-friendly delivery for international clients seeking world-class AI automation, fully remote.',
    cities: ['EU · UK', 'LATAM', 'APAC', 'Africa'],
  },
]

export const faqs = [
  {
    q: 'What AI and automation services do you provide?',
    a: 'Our services are organized into six pillars: AI Agent Development, AI Operating Systems, AI Marketing, AI Consulting, AI Training and Enablement, and Web and Mobile Development. AI Agent Development is the build arm, covering custom voice agents, chatbots, document processing, workflow automation, predictive analytics, and multi-agent systems. An AI Operating System then ties it all together in one place. Every solution is custom-built, never templated.',
  },
  {
    q: 'How much does AI and automation cost?',
    a: 'Every project is quoted based on its scope, complexity, and integrations. We offer project-based, hourly, and monthly retainer engagements, and you own what we build. Book a free 30-minute consultation and we will send you a clear custom quote before you commit.',
  },
  {
    q: 'Which industries benefit most?',
    a: 'Energy, technology, financial services, healthcare, real estate, logistics, and professional services all see strong results. The common thread is that any business dealing with repetitive manual processes, data entry, or high-volume communications stands to benefit significantly from AI-powered automation.',
  },
  {
    q: 'Do you work with businesses outside your region?',
    a: 'Yes. Our remote delivery model works seamlessly regardless of your location. We run discovery sessions, system analysis, development, and ongoing support through virtual collaboration and secure remote access, with flexible scheduling across time zones.',
  },
  {
    q: 'What makes your solutions different?',
    a: 'We are vendor-agnostic. We combine n8n, ChatGPT, Gemini, Python, Retell AI, and more to build the best solution for each use case, rather than locking you into a single platform. Every solution is fully managed with 24/7 monitoring, and we measure success by ROI, not just technical delivery.',
  },
  {
    q: 'How quickly can you implement solutions?',
    a: 'Simple single-workflow automations typically go live within one to two weeks. Comprehensive integrations with chatbots or voice agents take 2 to 6 weeks. Enterprise-scale deployments usually take two to three months, and we offer phased rollouts that deliver value incrementally.',
  },
]

export const posts = [
  {
    category: 'AI Agents & Architecture',
    date: 'October 6, 2026',
    title: 'Enterprise MJ Automation Glossary: Architecture and Execution',
    excerpt: 'A practical reference for enterprise AI models, agents, integrations, reasoning, retrieval, guardrails, and reliability.',
    read: '9 min read',
  },
  {
    category: 'Business Automation',
    date: 'October 1, 2026',
    title: 'Accounting Workflow Automation Is Rewriting Modern Finance',
    excerpt: 'AI, RPA, and connected finance tools are turning manual accounting into faster, controlled, scalable workflows.',
    read: '9 min read',
  },
  {
    category: 'Business Automation',
    date: 'September 29, 2026',
    title: 'AI Receptionist for Small Business: Costs, ROI, Labor Savings',
    excerpt: 'Compare AI receptionist pricing, labor savings, missed-call revenue, ROI, and integration requirements.',
    read: '8 min read',
  },
]
